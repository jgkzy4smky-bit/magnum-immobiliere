'use client'
import { motion } from 'framer-motion';
export const Hero = () => {
  return (
    <section className="h-[90vh] flex flex-col justify-center px-6 lg:px-12 relative overflow-hidden">
      <div className="max-w-7xl mx-auto w-full z-10">
        <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1.2, delay: 0.2 }}>
          <h2 className="text-sm tracking-[0.2em] uppercase text-premium-accent mb-6">{{TAGLINE}}</h2>
          <h1 className="text-6xl md:text-8xl lg:text-9xl leading-[0.9] -ml-2 mb-12">L'Architecture<br />de l'Émotion.</h1>
        </motion.div>
      </div>
    </section>
  );
};