import ProjectCard from "@/components/ui/ProjectCard";
export const SelectedProjects = () => {
  const projects = [{ id: 1, title: "{{PROJECT_NAME}}", location: "{{PROJECT_LOCATION}}", image: "/api/placeholder/800/1200", slug: "projet-1" }];
  return (
    <section className="py-32 px-6 lg:px-12 bg-premium-light">
      <h2 className="text-4xl font-serif mb-16">Projets Récents</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {projects.map(p => <ProjectCard key={p.id} {...p} />)}
      </div>
    </section>
  );
}