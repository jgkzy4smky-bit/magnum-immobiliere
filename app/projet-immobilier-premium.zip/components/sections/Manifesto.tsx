export const Manifesto = () => {
  return (
    <section className="py-32 px-6 lg:px-12 bg-premium-dark text-premium-light">
      <div className="max-w-4xl mx-auto text-center">
        <h3 className="text-3xl md:text-5xl leading-tight mb-12">"Chaque détail doit communiquer : architecture, précision, élégance, exclusivité, qualité."</h3>
        <p className="text-premium-muted uppercase tracking-widest text-sm">— La Vision {{COMPANY_NAME}}</p>
      </div>
    </section>
  );
}