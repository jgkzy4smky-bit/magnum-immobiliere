export default function Footer() {
  return (
    <footer className="bg-premium-dark text-premium-light py-24 px-6 lg:px-12">
      <div className="container mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="md:col-span-2">
          <h2 className="text-4xl font-serif mb-8">{{COMPANY_NAME}}</h2>
          <p className="max-w-sm text-premium-muted font-sans leading-relaxed">{{PROJECT_DESCRIPTION}}</p>
        </div>
        <div>
          <h4 className="text-xs uppercase tracking-widest text-premium-accent mb-6">Contact</h4>
          <ul className="space-y-4 font-sans text-sm">
            <li><a href={`mailto:${'{{EMAIL}}'}`} className="hover:text-white transition-colors">{{EMAIL}}</a></li>
            <li><a href={`tel:${'{{PHONE}}'}`} className="hover:text-white transition-colors">{{PHONE}}</a></li>
            <li className="pt-4 text-premium-muted">{{ADDRESS}}<br/>{{CITY}}, {{COUNTRY}}</li>
          </ul>
        </div>
      </div>
    </footer>
  );
}