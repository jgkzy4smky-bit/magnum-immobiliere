'use client'
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  return (
    <motion.header 
      className={`fixed top-0 w-full z-50 transition-colors duration-500 ${scrolled ? 'bg-premium-light/90 backdrop-blur-md' : 'bg-transparent'}`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
    >
      <div className="container mx-auto px-6 lg:px-12 h-24 flex items-center justify-between">
        <Link href="/" className="text-xl font-serif tracking-widest uppercase relative z-10">{{COMPANY_NAME}}</Link>
        <nav className="hidden md:flex space-x-12 text-sm tracking-widest uppercase font-sans">
          <Link href="/projects" className="hover:text-premium-accent transition-colors">Projets</Link>
          <Link href="/expertise" className="hover:text-premium-accent transition-colors">Expertise</Link>
          <Link href="/contact" className="hover:text-premium-accent transition-colors">Contact</Link>
        </nav>
        <button className="md:hidden text-sm uppercase tracking-widest">Menu</button>
      </div>
    </motion.header>
  );
}