'use client'
import Link from 'next/link';
import { motion } from 'framer-motion';
interface Props { title: string; location: string; image: string; slug: string; }
export default function ProjectCard({ title, location, image, slug }: Props) {
  return (
    <Link href={`/projects/${slug}`} className="group block">
      <div className="relative overflow-hidden aspect-[3/4] mb-6 bg-premium-dark/5">
        <motion.img src={image} alt={title} className="object-cover w-full h-full transition-transform duration-1000 group-hover:scale-105" whileHover={{ scale: 1.05 }} />
      </div>
      <div>
        <h3 className="text-2xl font-serif mb-2">{title}</h3>
        <p className="text-sm font-sans tracking-widest text-premium-accent uppercase">{location}</p>
      </div>
    </Link>
  );
}