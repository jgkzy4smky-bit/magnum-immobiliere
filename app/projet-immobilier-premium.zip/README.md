# {{COMPANY_NAME}} - Expérience Digitale Premium

## Installation locale
1. `npm install`
2. `npm run dev`
Le site sera disponible sur `http://localhost:3000`.