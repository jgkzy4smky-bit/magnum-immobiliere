import ProjectCard from "@/components/ui/ProjectCard";
export default function Projects() {
  const projects = [
    { id: 1, title: "{{PROJECT_NAME}}", location: "{{PROJECT_LOCATION}}", image: "/api/placeholder/800/1200", slug: "projet-1" },
    { id: 2, title: "Villa Horizon", location: "{{CITY}}", image: "/api/placeholder/800/1200", slug: "projet-2" },
  ];
  return (
    <div className="px-6 lg:px-12 py-24 min-h-screen">
      <h1 className="text-5xl md:text-7xl mb-24 font-serif">Portfolio.</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-24">
        {projects.map((p, i) => (
          <div key={p.id} className={i % 2 !== 0 ? "md:mt-32" : ""} >
            <ProjectCard {...p} />
          </div>
        ))}
      </div>
    </div>
  );
}