import type { Metadata } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "../styles/globals.css";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import SmoothScroll from "@/components/layout/SmoothScroll";

const inter = Inter({ subsets: ["latin"], variable: '--font-primary' });
const playfair = Playfair_Display({ subsets: ["latin"], variable: '--font-secondary' });

export const metadata: Metadata = {
  title: "{{COMPANY_NAME}} | {{TAGLINE}}",
  description: "Découvrez notre vision de l'immobilier premium. {{PROJECT_DESCRIPTION}}",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" className={`${inter.variable} ${playfair.variable}`}>
      <body>
        <SmoothScroll>
          <Header />
          <main className="min-h-screen pt-24">
            {children}
          </main>
          <Footer />
        </SmoothScroll>
      </body>
    </html>
  );
}