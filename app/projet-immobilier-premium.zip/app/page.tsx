import { Hero } from "@/components/sections/Hero";
import { SelectedProjects } from "@/components/sections/SelectedProjects";
import { Manifesto } from "@/components/sections/Manifesto";
export default function Home() {
  return (
    <>
      <Hero />
      <Manifesto />
      <SelectedProjects />
    </>
  );
}