import type { Config } from "tailwindcss";
const config: Config = {
  content: [
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        premium: {
          dark: "#0A0A0A",
          light: "#F5F5F3",
          accent: "#8C857B",
          muted: "#A3A3A3",
        }
      },
      fontFamily: {
        sans: ['var(--font-primary)'],
        serif: ['var(--font-secondary)'],
      },
      letterSpacing: {
        widest: '.15em',
      }
    },
  },
  plugins: [],
};
export default config;